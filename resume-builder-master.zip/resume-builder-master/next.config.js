module.exports = {
    env: {
        HOST: process.env.HOST,
    },
};

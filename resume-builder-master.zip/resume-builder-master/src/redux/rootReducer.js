// import { combineReducers } from 'redux';
import core from './core/reducer'; //put any name

// const rootReducer = combineReducers({
//     core: core
// })
export default core;

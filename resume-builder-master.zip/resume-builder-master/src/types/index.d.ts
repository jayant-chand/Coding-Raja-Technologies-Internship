declare module 'gsap/dist/gsap';

export interface TProps {
    userData: {
        [key: string]: string;
    };
}
